import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, average_precision_score,
                             confusion_matrix, roc_curve, precision_recall_curve)
import matplotlib.pyplot as plt
import joblib
import shap


class RifampicinGBCAnalysis:
    """
    Gradient Boosting Classifier for Rifampicin Resistance Prediction
    """

    def __init__(self, random_state=42):
        self.random_state = random_state
        self.model = GradientBoostingClassifier(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=3,
            random_state=random_state
        )
        self.feature_importance = None
        self.cv_results = None

    def load_data(self, train_file, test_file=None):
        """Load training and optional test data"""
        print("Loading data...")
        self.train_data = pd.read_csv(train_file)

        # Separate features and labels
        self.X_train = self.train_data.iloc[:, 1:-1]  # All columns except first (ID) and last (phenotype)
        self.y_train = self.train_data.iloc[:, -1]  # Last column is phenotype
        self.feature_names = self.X_train.columns.tolist()

        print(f"Training data shape: {self.X_train.shape}")
        print(f"Class distribution: {dict(self.y_train.value_counts())}")

        if test_file:
            self.test_data = pd.read_csv(test_file)
            # Check if test data has phenotype column (last column)
            if self.test_data.shape[1] == self.train_data.shape[1]:
                # Test data has phenotype - extract it for evaluation
                self.X_test = self.test_data.iloc[:, 1:-1]
                self.y_test = self.test_data.iloc[:, -1]
                print(f"Test data shape: {self.X_test.shape}")
                print(f"Test data has phenotype labels for evaluation")
                print(f"Test class distribution: {dict(self.y_test.value_counts())}")
            else:
                # Test data doesn't have phenotype
                self.X_test = self.test_data.iloc[:, 1:]
                self.y_test = None
                print(f"Test data shape: {self.X_test.shape}")

    def cross_validate_model(self, n_splits=6):
        """Perform stratified k-fold cross-validation"""
        print(f"\nPerforming {n_splits}-fold cross-validation...")

        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=self.random_state)

        scoring = {
            'accuracy': 'accuracy',
            'precision': 'precision',
            'recall': 'recall',
            'f1': 'f1',
            'roc_auc': 'roc_auc',
            'average_precision': 'average_precision'
        }

        self.cv_results = cross_validate(
            self.model, self.X_train, self.y_train,
            cv=skf, scoring=scoring, return_train_score=True,
            n_jobs=-1
        )

        # Print results
        print("\nCross-Validation Results:")
        print("-" * 60)
        for metric in ['accuracy', 'precision', 'recall', 'f1', 'roc_auc', 'average_precision']:
            test_scores = self.cv_results[f'test_{metric}']
            print(f"{metric.upper():20s}: {test_scores.mean():.4f} (+/- {test_scores.std():.4f})")

        return self.cv_results

    def train_final_model(self):
        """Train the final model on all training data"""
        print("\nTraining final model...")
        self.model.fit(self.X_train, self.y_train)

        # Get feature importance
        self.feature_importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)

        print("\nTop 15 Most Important Features:")
        print(self.feature_importance.head(15))

        return self.model

    def evaluate_on_test(self):
        """Evaluate model on test set if available"""
        if not hasattr(self, 'X_test'):
            print("No test data available")
            return None

        y_pred = self.model.predict(self.X_test)
        y_proba = self.model.predict_proba(self.X_test)[:, 1]

        predictions = pd.DataFrame({
            'Sample_ID': self.test_data.iloc[:, 0],
            'Predicted_Phenotype': y_pred,
            'Resistance_Probability': y_proba
        })

        return predictions

    def calculate_shap_values(self, sample_size=100):
        """Calculate SHAP values for model interpretation"""
        print("\nCalculating SHAP values...")

        # Use a sample for faster computation
        if len(self.X_train) > sample_size:
            sample_indices = np.random.choice(len(self.X_train), sample_size, replace=False)
            X_sample = self.X_train.iloc[sample_indices]
        else:
            X_sample = self.X_train

        explainer = shap.TreeExplainer(self.model)
        self.shap_values = explainer.shap_values(X_sample)
        self.shap_data = X_sample

        return self.shap_values

    def plot_results(self, save_dir='./'):
        """Generate visualization plots"""

        # 1. Feature Importance Plot
        plt.figure(figsize=(10, 8))
        top_features = self.feature_importance.head(20)
        plt.barh(range(len(top_features)), top_features['importance'])
        plt.yticks(range(len(top_features)), top_features['feature'])
        plt.xlabel('Feature Importance')
        plt.title('Top 20 Feature Importance (Gradient Boosting)')
        plt.tight_layout()
        plt.savefig(f'{save_dir}/feature_importance.png', dpi=300, bbox_inches='tight')
        plt.close()

        # 2. Cross-Validation Performance
        if self.cv_results:
            metrics = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']
            test_scores = [self.cv_results[f'test_{m}'].mean() for m in metrics]

            plt.figure(figsize=(10, 6))
            plt.bar(range(len(metrics)), test_scores)
            plt.xticks(range(len(metrics)), [m.upper() for m in metrics])
            plt.ylabel('Score')
            plt.title('Cross-Validation Performance Metrics')
            plt.ylim(0, 1)
            for i, v in enumerate(test_scores):
                plt.text(i, v + 0.01, f'{v:.3f}', ha='center')
            plt.tight_layout()
            plt.savefig(f'{save_dir}/cv_performance.png', dpi=300, bbox_inches='tight')
            plt.close()

        # 3. SHAP Summary Plot (if calculated)
        if hasattr(self, 'shap_values'):
            plt.figure(figsize=(10, 8))
            shap.summary_plot(self.shap_values, self.shap_data, show=False)
            plt.tight_layout()
            plt.savefig(f'{save_dir}/shap_summary.png', dpi=300, bbox_inches='tight')
            plt.close()

    def save_model(self, filename='rifampicin_GBC.sav'):
        """Save the trained model"""
        joblib.dump(self.model, filename)
        print(f"\nModel saved to {filename}")

    def save_results(self, save_dir='./'):
        """Save all results to CSV files"""

        # Save feature importance
        self.feature_importance.to_csv(f'{save_dir}/feature_importance.csv', index=False)

        # Save cross-validation results
        if self.cv_results:
            cv_df = pd.DataFrame({
                metric: self.cv_results[f'test_{metric}']
                for metric in ['accuracy', 'precision', 'recall', 'f1', 'roc_auc', 'average_precision']
            })
            cv_df.to_csv(f'{save_dir}/cv_results.csv', index=False)

        print(f"\nResults saved to {save_dir}")


def main():
    """Main execution function"""

    # Initialize the analyzer
    analyzer = RifampicinGBCAnalysis(random_state=42)

    # Load data
    # Replace with your actual file paths
    analyzer.load_data(
        train_file='rifampicin.csv',
        test_file='rifampicin_to_predict_MTB.csv'  # Optional
    )

    # Perform cross-validation
    analyzer.cross_validate_model(n_splits=6)

    # Train final model
    analyzer.train_final_model()

    # Calculate SHAP values
    analyzer.calculate_shap_values(sample_size=100)

    # Make predictions on test set (if available)
    predictions = analyzer.evaluate_on_test()
    if predictions is not None:
        predictions.to_csv('rifampicin_predictions.csv', index=False)
        print("\nPredictions saved to rifampicin_predictions.csv")

    # Generate plots
    analyzer.plot_results(save_dir='./')

    # Save model
    analyzer.save_model('rifampicin_GBC.sav')

    # Save all results
    analyzer.save_results(save_dir='./')

    print("\nAnalysis complete!")


if __name__ == "__main__":
    main()