#!/usr/bin/env python
"""
===============================================================================
MTB-AMR Reproducibility Study - GaussianNB Figure Generation
===============================================================================
Author: Sean
Course: BINF6310 Introduction to Computational Methods in Bioinformatics
Date: December 2024
Institution: Northeastern University

Paper: Machine learning-based prediction of antimicrobial resistance and 
       identification of AMR-related SNPs in Mycobacterium tuberculosis
       Xu, Y., Mao, Y., et al. (2025). BMC Genomic Data.
       https://github.com/microbial123/MTB-AMR

Purpose:
    Generate publication-quality figures for GaussianNB analysis:
    - Figure 2A: 9-panel performance comparison
    - Figure 2B: 4-panel SHAP analysis (feature importance + interpretability)

Key Fixes Applied:
    1. SHAP compatibility: Extract 2D from 3D array for KernelExplainer
    2. Panel ordering: Corrected ii (bar) and iii (beeswarm) placement
    3. Figure sizing: Use plot_size=(8, 8) for proper feature display
    4. Portability: Cross-platform backend detection and path handling
    5. Consistent styling: Panel i now uses full feature names like panels ii/iii
    6. Waterfall layout: Increased height to prevent label overflow

Usage:
    python mtb_amr_gnb_analysis_FINAL.py
    
    Run from repository root directory (same level as example/ folder)

See README_gNB.md for details and writeup document for analysis.
===============================================================================
"""

# ============================================================================
# PORTABILITY SETUP - Must come BEFORE other imports
# ============================================================================

import os
import platform
import warnings

# Suppress FutureWarning from SHAP/NumPy
warnings.filterwarnings('ignore', category=FutureWarning)

# Detect headless environment (HPC/server)
import matplotlib
if os.environ.get('DISPLAY') is None and platform.system() != 'Windows':
    matplotlib.use('Agg')

# ============================================================================
# IMPORTS
# ============================================================================

import pandas as pd                   # Data analysis and manipulation
import numpy as np                    # Array operations and numerical computing
import matplotlib.pyplot as plt       # Data visualization and plotting
import seaborn as sns                 # Statistical data visualization
from matplotlib import rc             # Runtime configuration for matplotlib
import textwrap as tw                 # Text wrapping for figure captions
from pathlib import Path              # File system path operations
from datetime import datetime         # Timestamp generation
from matplotlib.patches import Patch  # Legend creation
import shap                           # SHAP explainability analysis
import pickle                         # Model serialization
from sklearn.ensemble import ExtraTreesClassifier  # Feature importance baseline
from sklearn.naive_bayes import GaussianNB        # Model for training

warnings.filterwarnings('ignore')
sns.set()

print("="*80)
print("MTB-AMR FIGURE GENERATION - GAUSSIANNB ANALYSIS")
print("="*80)
print(f"Platform: {platform.system()}")
print(f"SHAP version: {shap.__version__}")
print(f"Matplotlib version: {plt.matplotlib.__version__}")
print(f"Backend: {matplotlib.get_backend()}")
print("="*80 + "\n")


# ============================================================================
# FIGURE 2A: 9-PANEL PERFORMANCE COMPARISON
# ============================================================================

def create_figure_2a(
    source_dir='example',
    antibiotic='rifampicin',
    model='gNB',
    validation_no=6,
    save_individual_panels=True,
    show_individual_panels=False
):
    """
    Generate Figure 2A: Performance comparison across dataset types.
    
    Creates 9-panel visualization comparing:
        - All Set (all SNPs)
        - Intersection Set (top 15 SNPs)
        - Random Set (15 random SNPs, negative control)
    """
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = Path(f'figures_2a_{timestamp}')
    output_dir.mkdir(exist_ok=True)
    
    print(f"\nGENERATING FIGURE 2A: {antibiotic.upper()} - {model}")
    print(f"Output: {output_dir}/\n")
    
    source_dir = Path(source_dir)
    
    # Load performance data
    all_set = pd.read_csv(source_dir / f'MTB_{antibiotic}_All_Set_Performance_6-fold_CV.csv')
    int_set = pd.read_csv(source_dir / f'MTB_{antibiotic}_Intersection_Set_Performance_6-fold_CV.csv')
    rand_set = pd.read_csv(source_dir / f'MTB_{antibiotic}_Random_Set_Performance_6-fold_CV.csv')
    
    # Extract model results
    m_all = all_set[all_set['classifier'] == model].iloc[0]
    m_int = int_set[int_set['classifier'] == model].iloc[0]
    m_rand = rand_set[rand_set['classifier'] == model].iloc[0]
    
    # Configuration
    datasets = ['All\nSet', 'Intersection\nSet', 'Random\nSet']
    bar_colors = ['#2c3e50', '#f39c12', '#bdc3c7']  # Dark blue, orange, gray
    
    # Prepare metrics
    metrics = [
        ('tr_precision_avg', 'i. Training precision'),
        ('tr_recall_avg', 'ii. Training recall'),
        ('tr_f1_avg', 'iii. Training F1'),
        ('te_precision_avg', 'iv. Test precision'),
        ('te_recall_avg', 'v. Test recall'),
        ('te_f1_avg', 'vi. Test F1'),
        ('Tf_CV_Avg', 'vii. 10-fold CV'),
        ('Loo_CV', 'viii. LOO CV'),
        ('au_ROC_avg', 'ix. AU-ROC')
    ]
    
    metrics_data = []
    for metric, title in metrics:
        # Handle column name inconsistency in Random Set CSV
        if metric == 'Loo_CV':
            values = [m_all['Loo_CV'], m_int['Loo_CV'], m_rand['Loo_CV_Avg']]
        else:
            values = [m_all[metric], m_int[metric], m_rand[metric]]
        metrics_data.append({'title': title, 'values': values})
    
    # Generate individual panels if requested
    if save_individual_panels or show_individual_panels:
        print("Generating individual panels...")
        
        for metric_info in metrics_data:
            panel_fig, panel_ax = plt.subplots(figsize=(8, 6))
            title = metric_info['title']
            values = metric_info['values']
            x_pos = np.arange(len(datasets))
            
            bars = panel_ax.bar(x_pos, values, width=0.7, color=bar_colors,
                              edgecolor='#555', linewidth=0.8, alpha=0.95)
            
            panel_ax.set_xticks(x_pos)
            panel_ax.set_xticklabels(datasets, fontsize=14)
            panel_ax.set_yticks(np.arange(0, 1.1, 0.2))
            panel_ax.set_ylim([0, 1.05])
            panel_ax.grid(linestyle='-', color='#666', axis='y', alpha=0.3, lw=0.5)
            panel_ax.set_axisbelow(True)
            panel_ax.set_title(title, fontsize=16, fontweight='bold', pad=15)
            panel_ax.tick_params(axis='y', labelsize=14)
            panel_ax.tick_params(axis='x', labelsize=13)
            
            # Add axis labels to individual panels with larger font
            panel_ax.set_xlabel('Dataset', fontsize=14, fontweight='bold')
            panel_ax.set_ylabel('Performance', fontsize=14, fontweight='bold')
            
            legend_elements = [
                Patch(facecolor='#2c3e50', edgecolor='#555', label='All Set'),
                Patch(facecolor='#f39c12', edgecolor='#555', label='Intersection Set'),
                Patch(facecolor='#bdc3c7', edgecolor='#555', label='Random Set')
            ]
            panel_ax.legend(handles=legend_elements, loc='upper right', 
                          prop={'size': 12}, frameon=True, edgecolor='#666')
            
            panel_fig.tight_layout()
            
            if save_individual_panels:
                panel_name = title.replace('. ', '_').replace(' ', '_')
                panel_fig.savefig(output_dir / f'Panel_{panel_name}.png', 
                                dpi=300, bbox_inches='tight', facecolor='white')
                print(f"  ✓ Panel_{panel_name}.png")
            
            if show_individual_panels:
                plt.show()
            
            plt.close(panel_fig)
        
        print(f"✓ Individual panels complete")
    
    # Generate complete 9-panel figure
    print("Generating complete 9-panel figure...")
    
    rc('text', usetex=False)
    fig, axes = plt.subplots(3, 3, figsize=(22, 16))
    
    for i, metric_info in enumerate(metrics_data):
        row, col = i // 3, i % 3
        ax = axes[row, col]
        
        title = metric_info['title']
        values = metric_info['values']
        x_pos = np.arange(len(datasets))
        
        bars = ax.bar(x_pos, values, width=0.7, color=bar_colors,
                     edgecolor='#555', linewidth=0.6, alpha=0.95)
        
        ax.set_xticks(x_pos)
        ax.set_xticklabels(datasets, fontsize=13)
        ax.set_yticks(np.arange(0, 1.1, 0.2))
        ax.set_ylim([0, 1.05])
        ax.grid(linestyle='-', color='#666666', axis='y', alpha=0.3, lw=0.5)
        ax.set_axisbelow(True)
        ax.set_title(title, fontsize=17, fontweight='bold', pad=18)
        ax.tick_params(axis='y', labelsize=15)
        ax.tick_params(axis='x', labelsize=13)
        ax.set_ylabel('')
    
    # Add figure-level legend
    legend_elements = [
        Patch(facecolor='#2c3e50', edgecolor='#555', label='All Set'),
        Patch(facecolor='#f39c12', edgecolor='#555', label='Intersection Set'),
        Patch(facecolor='#bdc3c7', edgecolor='#555', label='Random Set')
    ]
    
    fig.legend(handles=legend_elements, loc='lower center', ncol=3,
              bbox_to_anchor=(0.5, 0.04), prop={'size': 15},
              frameon=True, edgecolor='#666', framealpha=0.95, borderaxespad=1.5)
    
    # Add shared axis labels on edges - larger fonts, better positioning
    fig.text(0.5, 0.09, 'Dataset', ha='center', fontsize=17, fontweight='bold')
    fig.text(0.04, 0.5, 'Performance', va='center', rotation='vertical', 
             fontsize=17, fontweight='bold')
    
    # Add caption
    caption = (f"Figure 2A. Performance of {model} algorithm predicting "
              f"{antibiotic.upper()} resistance in MTB ({validation_no}-fold CV). "
              f"(i) training precision, (ii) training recall, (iii) training F1, "
              f"(iv) test precision, (v) test recall, (vi) test F1, "
              f"(vii) 10-fold CV, (viii) LOO CV, (ix) AU-ROC. "
              f"'All Set' = all SNPs for training, "
              f"'Intersection Set' = consistently high-ranked SNPs across folds, "
              f"'Random Set' = randomly sampled SNPs.")
    
    fig_txt = tw.fill(caption, width=150)
    plt.figtext(0.5, 0.005, fig_txt, horizontalalignment='center', 
               fontsize=15, multialignment='left', color='#222')
    
    # Adjust spacing to accommodate shared labels
    plt.subplots_adjust(top=0.97, bottom=0.16, left=0.08, hspace=0.55, wspace=0.18)
    
    # Save
    base_2a = f'Figure_2A_{antibiotic}_{model}_Final'
    plt.savefig(output_dir / f'{base_2a}.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.savefig(output_dir / f'{base_2a}.pdf', dpi=300, bbox_inches='tight')
    
    print(f"✓ Saved: {base_2a}.png and .pdf")
    
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    plt.close()
    
    return output_dir


# ============================================================================
# FIGURE 2B PANELS i-iii: SHAP ANALYSIS
# ============================================================================

def create_figure_2b_shap_panels(
    source_dir='example',
    antibiotic='rifampicin',
    model='gNB',
    validation_no=6,
    n_shap_samples=200,
    n_shap_background=100,
    random_seed=42
):
    """
    Generate Figure 2B panels i-iii: Feature importance and SHAP analysis.
    
    Panel i: Feature importance (ExtraTreesClassifier)
    Panel ii: Mean |SHAP| bar plot
    Panel iii: SHAP beeswarm plot
    
    CRITICAL FIX: Handles 3D SHAP arrays from KernelExplainer and uses
    plot_size=(8, 8) to ensure all 15 features display properly.
    """
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_dir = Path(f'figures_2b_{timestamp}')
    output_dir.mkdir(exist_ok=True)
    
    print(f"\nGENERATING FIGURE 2B (Panels i-iii): {antibiotic.upper()} - {model}")
    print(f"Output: {output_dir}/\n")
    
    source_dir = Path(source_dir)
    
    # Load training data
    data = pd.read_csv(source_dir / f'{antibiotic}.csv')
    X = data.iloc[:, 1:-1]
    Y = data.iloc[:, -1]
    
    # Load top 15 features
    features_file = list(source_dir.glob(f"*Consistent*{validation_no}*.csv"))[0]
    top_15 = pd.read_csv(features_file)['Feature'].head(15).tolist()
    positions = [f.split('_')[-1] for f in top_15]
    
    X_top15 = X[top_15]
    
    # Train model on top 15 features
    model_top15 = GaussianNB()
    model_top15.fit(X_top15, Y)
    
    # Calculate feature importance baseline
    etc = ExtraTreesClassifier(n_estimators=100, random_state=random_seed)
    etc.fit(X_top15, Y)
    tree_importance = etc.feature_importances_
    
    # Compute SHAP values
    print(f"Computing SHAP on {n_shap_samples} samples...")
    print(f"  Expected time: 3-5 minutes")
    
    shap_success = False
    
    try:
        np.random.seed(random_seed)
        
        # Sample for faster computation
        samp_idx = np.random.choice(len(X_top15), n_shap_samples, replace=False)
        bg_idx = np.random.choice(len(X_top15), n_shap_background, replace=False)
        
        X_sample = X_top15.iloc[samp_idx]
        X_background = X_top15.iloc[bg_idx]
        
        # KernelExplainer for GaussianNB (non-tree model)
        explainer = shap.KernelExplainer(model_top15.predict_proba, X_background)
        shap_values = explainer.shap_values(X_sample)
        
        # CRITICAL FIX: Extract 2D from 3D array (handles different SHAP versions)
        if isinstance(shap_values, list):
            # Older SHAP versions return list
            shap_vals = shap_values[1]
        else:
            # Newer SHAP versions return 3D array for binary classification
            if len(shap_values.shape) == 3:
                shap_vals = shap_values[:, :, 1]  # Extract positive class
            else:
                shap_vals = shap_values
        
        # Calculate mean |SHAP| for importance ranking
        mean_shap = np.abs(shap_vals).mean(axis=0)
        if len(mean_shap.shape) > 1:
            mean_shap = mean_shap.flatten()
        
        shap_importance = mean_shap[:len(positions)]
        shap_success = True
        
        print(f"✓ SHAP complete on {len(X_sample)} samples")
        
    except Exception as e:
        print(f"Warning: SHAP failed ({e}), using tree importance")
        shap_importance = tree_importance
        shap_success = False
    
    # Create importance dataframe
    imp_df = pd.DataFrame({
        'Position': positions,
        'Feature': top_15,
        'Importance': shap_importance
    }).sort_values('Importance', ascending=True)
    
    imp_df.to_csv(output_dir / f'{antibiotic}_{model}_importance.csv', index=False)
    
    # ========================================================================
    # PANEL i: Feature Importance (MATCHED to panels ii/iii styling)
    # ========================================================================
    
    print("Creating Panel i: Feature importance...")
    
    # Match Panel ii/iii dimensions: 8x8
    fig, ax = plt.subplots(figsize=(8, 8))
    ax.barh(range(len(imp_df)), imp_df['Importance'].values,
            color='#3498db', edgecolor='white', linewidth=0.8)
    ax.set_yticks(range(len(imp_df)))
    # Match Panel ii font sizes exactly
    ax.set_yticklabels(imp_df['Feature'].values, fontsize=13)
    ax.tick_params(axis='x', labelsize=11)
    # Make both axis labels same larger size and bold
    ax.set_xlabel('Feature Importance', fontsize=14, fontweight='bold')
    ax.set_ylabel('Feature', fontsize=14, fontweight='bold')
    # Left-aligned title, larger than labels
    ax.set_title(f'i. Feature Importance - {antibiotic.upper()}',
                 fontsize=14, fontweight='bold', pad=10, loc='left')
    ax.grid(axis='x', linestyle='-', color='white', alpha=0.7, lw=1)
    ax.set_axisbelow(True)
    plt.tight_layout()
    
    plt.savefig(output_dir / f'Panel_i_importance.png', dpi=300, bbox_inches='tight')
    plt.savefig(output_dir / f'Panel_i_importance.pdf', dpi=300, bbox_inches='tight')
    print("  ✓ Panel i saved")
    
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    plt.close()
    
    if not shap_success:
        print("⚠ Panels ii-iii skipped (SHAP unavailable)\n")
        return output_dir
    
    # ========================================================================
    # PANEL ii: Mean |SHAP| Bar Plot
    # ========================================================================
    
    print("Creating Panel ii: Mean |SHAP| bar plot...")
    
    X_display = X_sample.copy()
    X_display.columns = top_15
    
    # CRITICAL FIX: Use plot_size=(8, 8) for proper height
    shap.summary_plot(
        shap_vals, 
        X_display, 
        plot_type="bar", 
        show=False, 
        max_display=15,
        plot_size=(8, 8)
    )
    
    # Override SHAP's labels - make bold, larger, and fix x-label text
    ax = plt.gca()
    
    # Set y-axis label (SHAP may not show it by default)
    ax.set_ylabel('Feature', fontsize=14, fontweight='bold')
    
    # Override x-axis label with shorter text (SHAP's default is too long)
    ax.set_xlabel('mean(|SHAP value|)', fontsize=14, fontweight='bold')
    
    plt.title(f'ii. Mean |SHAP| Values - {antibiotic.upper()}',
             fontsize=14, fontweight='bold', loc='left', pad=10)
    plt.tight_layout()
    
    plt.savefig(output_dir / f'Panel_ii_mean_shap_bar.png', dpi=300, bbox_inches='tight')
    plt.savefig(output_dir / f'Panel_ii_mean_shap_bar.pdf', dpi=300, bbox_inches='tight')
    print("  ✓ Panel ii saved (all 15 features)")
    
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    plt.close()
    
    # ========================================================================
    # PANEL iii: SHAP Beeswarm
    # ========================================================================
    
    print("Creating Panel iii: SHAP beeswarm...")
    
    X_display = X_sample.copy()
    X_display.columns = top_15
    
    # CRITICAL FIX: Use plot_size=(8, 8) for proper height
    shap.summary_plot(
        shap_vals, 
        X_display, 
        show=False, 
        max_display=15,
        plot_size=(8, 8)
    )
    
    # Override SHAP's labels - make bold, larger, and add y-label
    ax = plt.gca()
    
    # Set y-axis label (left side where feature names are)
    ax.set_ylabel('Feature', fontsize=14, fontweight='bold')
    
    # Set x-axis label (SHAP creates one but make it bold)
    ax.set_xlabel('SHAP value (impact on model output)', fontsize=14, fontweight='bold')
    
    plt.title(f'iii. SHAP Beeswarm - {antibiotic.upper()}',
             fontsize=14, fontweight='bold', loc='left', pad=10)
    plt.tight_layout()
    
    plt.savefig(output_dir / f'Panel_iii_beeswarm.png', dpi=300, bbox_inches='tight')
    plt.savefig(output_dir / f'Panel_iii_beeswarm.pdf', dpi=300, bbox_inches='tight')
    print("  ✓ Panel iii saved (all 15 features)")
    
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    plt.close()
    
    print(f"✓ Figure 2B panels i-iii complete\n")
    
    return output_dir


# ============================================================================
# FIGURE 2B PANEL iv: WATERFALL PLOT (FIXED - increased height)
# ============================================================================

def create_waterfall_plot(
    data_path='example/rifampicin.csv',
    predict_path='example/rifampicin_to_predict_MTB.csv',
    model_path='example/rifampicin_gNB.sav',
    sample_idx=44,
    n_background=100,
    n_samples=50,
    output_dir=None
):
    """
    Generate waterfall plot showing individual SHAP contributions.
    
    Note: Waterfall used instead of force plot due to force plot's label 
    positioning issues with multiple features.
    """
    
    print(f"GENERATING PANEL iv: Waterfall Plot")
    print(f"  Sample: {sample_idx}\n")
    
    # Load data
    data = pd.read_csv(data_path)
    data2pre = pd.read_csv(predict_path)
    
    Train_data_X = data.iloc[:, 1:-1]
    Train_data_Y = data.iloc[:, -1]
    data2pre_X = data2pre.iloc[:, 1:-1]
    
    # Load model
    model = pickle.load(open(model_path, 'rb'))
    model_name = type(model).__name__
    
    # Select SHAP explainer based on model type
    tree_based_models = [
        'RandomForestClassifier', 'GradientBoostingClassifier', 
        'ExtraTreesClassifier', 'XGBClassifier', 'LGBMClassifier',
        'DecisionTreeClassifier', 'AdaBoostClassifier', 'BaggingClassifier'
    ]
    
    if model_name in tree_based_models:
        print("  Using TreeExplainer...")
        explainer = shap.TreeExplainer(model)
        shap_values2 = explainer.shap_values(data2pre_X)
    else:
        print(f"  Using KernelExplainer (~2 minutes)...")
        background = shap.sample(Train_data_X, n_background)
        explainer = shap.KernelExplainer(model.predict_proba, background)
        
        # Limit computation for speed
        if n_samples is not None and len(data2pre_X) > n_samples:
            sample_indices = np.random.choice(len(data2pre_X), n_samples, replace=False)
            data2pre_X = data2pre_X.iloc[sample_indices]
            if sample_idx >= len(sample_indices):
                sample_idx = 0
        
        shap_values2 = explainer.shap_values(data2pre_X)
    
    # Extract positive class SHAP values
    if isinstance(shap_values2, list):
        shap_values2 = shap_values2[1]
    
    # Extract expected value
    if isinstance(explainer.expected_value, list):
        expected_value = float(explainer.expected_value[1])
    elif isinstance(explainer.expected_value, np.ndarray):
        expected_value = float(explainer.expected_value.flatten()[0])
    else:
        expected_value = float(explainer.expected_value)
    
    print(f"  ✓ SHAP complete")
    
    # Prepare data for visualization
    sample_shap = np.array(shap_values2[sample_idx]).flatten()
    sample_features = data2pre_X.iloc[sample_idx].values
    feature_names = data2pre_X.columns.tolist()
    abs_sorted_idx = np.argsort(np.abs(sample_shap))[::-1]
    
    final_prediction = expected_value + np.sum(sample_shap)
    
    # Create waterfall plot - FIXED: Increased height to prevent overflow
    fig, ax = plt.subplots(figsize=(12, 10))  # Increased from (12, 8)
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    
    # Display top 6 features
    contributions = []
    colors_list = []
    labels_list = []
    
    waterfall_n = min(6, len(abs_sorted_idx))
    
    for i in range(waterfall_n):
        idx = abs_sorted_idx[i]
        shap_contrib = float(sample_shap[idx])
        feat_val = float(sample_features[idx])
        
        full_name = feature_names[idx]
        short_name = str(full_name).split('_')[-1] if '_' in str(full_name) else str(full_name)[:12]
        
        contributions.append(shap_contrib)
        colors_list.append('#ff1493' if shap_contrib > 0 else '#1e90ff')
        labels_list.append(f'Pos {short_name}={int(feat_val)}')
    
    # Draw bars
    y_positions = np.arange(len(contributions))
    bars = ax.barh(y_positions, contributions, color=colors_list, 
                   edgecolor='none', height=0.7, alpha=0.95)
    
    # Add value labels with larger font matching overall scheme
    for i, contrib in enumerate(contributions):
        x_pos = contrib + (0.002 if contrib > 0 else -0.002)
        ha = 'left' if contrib > 0 else 'right'
        
        ax.text(x_pos, i, f'{contrib:+.4f}', va='center', ha=ha,
               fontsize=13, fontweight='bold', color='#333',
               bbox=dict(boxstyle='round,pad=0.3', facecolor='white', 
                        edgecolor='#666', linewidth=1.2, alpha=0.95))
    
    # Styling - matched to Panel ii fonts exactly
    ax.set_yticks(y_positions)
    ax.set_yticklabels(labels_list, fontsize=13)  # Match Panel ii y-ticks
    ax.tick_params(axis='x', labelsize=11)  # Match Panel ii x-ticks
    ax.axvline(x=0, color='#333', linestyle='-', linewidth=3, alpha=0.8)
    ax.set_xlabel('SHAP Value', fontsize=14, fontweight='bold', labelpad=10)
    ax.set_ylabel('Feature', fontsize=14, fontweight='bold', labelpad=15)
    # Left-aligned title, same as other panels
    ax.set_title(f'iv. Waterfall - Sample {sample_idx} ({model_name})', 
                fontsize=14, fontweight='bold', pad=15, loc='left')
    ax.grid(axis='x', linestyle=':', alpha=0.4, linewidth=1)
    ax.invert_yaxis()

    # After ax.invert_yaxis(), ADD THIS:
    print(f"\nPanel iv font inspection:")
    print(f"  Y-tick labels: {ax.yaxis.get_ticklabels()[0].get_fontsize()}")
    print(f"  X-tick labels: {ax.xaxis.get_ticklabels()[0].get_fontsize()}")
    print(f"  X-axis label: {ax.xaxis.label.get_fontsize()}")
    print(f"  Y-axis label: {ax.yaxis.label.get_fontsize()}")
    print(f"  Title: {ax.title.get_fontsize()}")    
    
    
    
    x_min = min(contributions) - 0.012
    x_max = max(contributions) + 0.012
    ax.set_xlim([x_min, x_max])
    
    # Legend - increased font size
    legend_elements = [
        Patch(facecolor='#ff1493', label='Increases resistance'),
        Patch(facecolor='#1e90ff', label='Decreases resistance')
    ]
    ax.legend(handles=legend_elements, loc='lower right', fontsize=13, 
             frameon=True, shadow=False, framealpha=0.9)
    
    plt.tight_layout(pad=2.0)  # Added padding to prevent cutoff
    
    # Save to correct location
    if output_dir is None:
        output_name = f'Panel_iv_waterfall_{model_name}_sample{sample_idx}.png'
        output_path = Path(output_name)
    else:
        output_name = f'Panel_iv_waterfall_{model_name}_sample{sample_idx}.png'
        output_path = output_dir / output_name
    
    plt.savefig(output_path, dpi=200, bbox_inches='tight', facecolor='white')
    print(f"  ✓ Saved: {output_path}")


    
    if matplotlib.get_backend() != 'Agg':
        plt.show()
    
    return None


# ============================================================================
# MAIN EXECUTION
# ============================================================================

if __name__ == "__main__":
    
    print("\n" + "="*80)
    print("GENERATING ALL FIGURES FOR GAUSSIANNB ANALYSIS")
    print("="*80)
    print("\nFigures to generate:")
    print("  1. Figure 2A: 9-panel performance (~30 sec)")
    print("  2. Figure 2B Panel i: Feature importance (~5 sec)")
    print("  3. Figure 2B Panel ii: Mean |SHAP| bar (~3-5 min)")
    print("  4. Figure 2B Panel iii: SHAP beeswarm (~1 sec)")
    print("  5. Figure 2B Panel iv: Waterfall (~2 min)")
    print("\nTotal expected time: ~8-10 minutes")
    print("="*80 + "\n")
    
    # Generate Figure 2A
    print("STEP 1/3: Figure 2A (9-panel performance)")
    output_2a = create_figure_2a(
        source_dir='example',
        antibiotic='rifampicin',
        model='gNB',
        validation_no=6,
        save_individual_panels=True,
        show_individual_panels=False
    )
    
    # Generate Figure 2B panels i-iii
    print("\nSTEP 2/3: Figure 2B panels i-iii (SHAP analysis)")
    output_2b = create_figure_2b_shap_panels(
        source_dir='example',
        antibiotic='rifampicin',
        model='gNB',
        validation_no=6,
        n_shap_samples=200,
        n_shap_background=100,
        random_seed=42
    )
    
    # Generate Figure 2B panel iv
    print("\nSTEP 3/3: Figure 2B panel iv (Waterfall)")
    create_waterfall_plot(
        data_path='example/rifampicin.csv',
        predict_path='example/rifampicin_to_predict_MTB.csv',
        model_path='example/rifampicin_gNB.sav',
        sample_idx=44,
        n_background=100,
        n_samples=50,
        output_dir=output_2b
    )
    
    print("\n" + "="*80)
    print("ALL FIGURES GENERATED SUCCESSFULLY")
    print("="*80)
    print(f"\nOutput locations:")
    print(f"  Figure 2A: {output_2a.absolute()}/")
    print(f"  Figure 2B: {output_2b.absolute()}/")
    print("\nFor writeup: Generate additional waterfall samples by changing sample_idx")
    print("See README_gNB.md for usage details")
    print("="*80 + "\n")