"""
SHAP Analysis for SVM Rifampicin Resistance Prediction
Matches Figure 2B from Xu et al. BMC Genomic Data (2025)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
import joblib
import os
import warnings
warnings.filterwarnings('ignore')

print("="*60)
print("SHAP ANALYSIS FOR SVM - RIFAMPICIN RESISTANCE")
print("Reproducing Figure 2B from Xu et al. (2025)")
print("="*60)

# Load data
print("\n>>> Loading data...")
DATA_PATH = "Data/rifampicin_Top15.csv"
df = pd.read_csv(DATA_PATH)

phenotype_col = 'rifampicin'
columns_to_drop = [phenotype_col]
if 'Isolate' in df.columns:
    columns_to_drop.append('Isolate')

X = df.drop(columns=columns_to_drop)
y = df[phenotype_col]
feature_names = X.columns.tolist()
simple_names = [name.replace('NC_000962.3_', '') for name in feature_names]

print(f"Samples: {X.shape[0]}, Features: {X.shape[1]}")

# Load model
print("\n>>> Loading trained SVM model...")
model_data = joblib.load('rifampicin_SVM_Top15.sav')
svm_model = model_data['model']
scaler = model_data['scaler']
X_scaled = scaler.transform(X.values)
print("Model loaded!")

# Check for cached SHAP values
SHAP_CACHE = 'shap_values_cache.npz'

if os.path.exists(SHAP_CACHE):
    print("\n>>> Loading cached SHAP values...")
    cached = np.load(SHAP_CACHE, allow_pickle=True)
    shap_values_raw = cached['shap_values']
    X_explain_raw = cached['X_explain']
    expected_value = cached['expected_value']
    explain_idx = cached['explain_idx']
    print("Loaded from cache!")
else:
    print("\n>>> Calculating SHAP values (this takes ~30 min)...")
    np.random.seed(42)
    
    background_idx = np.random.choice(len(X_scaled), 100, replace=False)
    background = X_scaled[background_idx]
    
    explain_idx = np.random.choice(len(X_scaled), 200, replace=False)
    X_explain_raw = X_scaled[explain_idx]
    
    explainer = shap.KernelExplainer(svm_model.predict_proba, background)
    shap_values_raw = explainer.shap_values(X_explain_raw)
    expected_value = explainer.expected_value
    
    np.savez(SHAP_CACHE, 
             shap_values=np.array(shap_values_raw, dtype=object),
             X_explain=X_explain_raw,
             expected_value=expected_value,
             explain_idx=explain_idx)
    print("Calculated and cached!")

# Handle SHAP values format and convert to float64
print(f"\nRaw SHAP values shape: {shap_values_raw.shape}")

if len(shap_values_raw.shape) == 3:
    # Shape: (samples, features, classes) -> extract class 1
    shap_vals = np.array(shap_values_raw[:, :, 1], dtype=np.float64)
elif isinstance(shap_values_raw, list):
    shap_vals = np.array(shap_values_raw[1], dtype=np.float64)
else:
    shap_vals = np.array(shap_values_raw, dtype=np.float64)

# Convert X_explain to float64 as well
X_explain = np.array(X_explain_raw, dtype=np.float64)

print(f"Processed SHAP values shape: {shap_vals.shape}")
print(f"X_explain shape: {X_explain.shape}")

# Calculate mean absolute SHAP
mean_shap = np.abs(shap_vals).mean(axis=0)

# Create importance dataframe
importance_df = pd.DataFrame({
    'Position': simple_names,
    'Importance': mean_shap
}).sort_values('Importance', ascending=True)

# ============ FIGURE 2B i ============
print("\n>>> Generating Figure 2B i: Feature Importance...")
plt.figure(figsize=(8, 6))
plt.barh(importance_df['Position'], importance_df['Importance'], color='steelblue', edgecolor='black')
plt.xlabel('Feature Importance', fontsize=11)
plt.ylabel('Position', fontsize=11)
plt.title('Feature Importance', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('Figure_2Bi_feature_importance.png', dpi=300, bbox_inches='tight')
plt.show()
print("Saved: Figure_2Bi_feature_importance.png")

# ============ FIGURE 2B ii ============
print("\n>>> Generating Figure 2B ii: SHAP Summary Bar Plot...")
importance_desc = importance_df.sort_values('Importance', ascending=False)

plt.figure(figsize=(8, 6))
plt.barh(range(len(importance_desc)), importance_desc['Importance'], color='#1E88E5', edgecolor='black')
plt.yticks(range(len(importance_desc)), importance_desc['Position'])
plt.xlabel('Mean(|SHAP value|)\n(average impact on model output magnitude)', fontsize=10)
plt.ylabel('Position', fontsize=11)
plt.gca().invert_yaxis()
plt.title('SHAP Summary Plot', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('Figure_2Bii_shap_summary_bar.png', dpi=300, bbox_inches='tight')
plt.show()
print("Saved: Figure_2Bii_shap_summary_bar.png")

# ============ FIGURE 2B iii ============
print("\n>>> Generating Figure 2B iii: SHAP Beeswarm Plot...")
plt.figure(figsize=(10, 8))
shap.summary_plot(
    shap_vals,
    X_explain,
    feature_names=simple_names,
    show=False
)
plt.xlabel('SHAP value (impact on model output)', fontsize=11)
plt.title('SHAP Values of SNPs in the SVM Model', fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('Figure_2Biii_shap_beeswarm.png', dpi=300, bbox_inches='tight')
plt.show()
print("Saved: Figure_2Biii_shap_beeswarm.png")

# ============ FIGURE 2B iv ============
print("\n>>> Generating Figure 2B iv: SHAP Force Plot...")
y_explain = y.values[explain_idx]
resistant_idx = np.where(y_explain == 1)[0]

if len(resistant_idx) > 0:
    idx = resistant_idx[0]
    
    # Get expected value for class 1
    if hasattr(expected_value, '__len__') and len(expected_value) > 1:
        exp_val = float(expected_value[1])
    else:
        exp_val = float(expected_value)
    
    plt.figure(figsize=(14, 3))
    shap.force_plot(
        exp_val,
        shap_vals[idx],
        X_explain[idx],
        feature_names=simple_names,
        matplotlib=True,
        show=False
    )
    plt.title('SHAP Force Plot - Single MTB Isolate Prediction', fontsize=11)
    plt.tight_layout()
    plt.savefig('Figure_2Biv_shap_force_plot.png', dpi=300, bbox_inches='tight')
    plt.show()
    print("Saved: Figure_2Biv_shap_force_plot.png")

# ============ SUMMARY TABLE ============
print("\n" + "="*60)
print("SHAP FEATURE IMPORTANCE RANKING")
print("="*60)

final_ranking = importance_df.sort_values('Importance', ascending=False).reset_index(drop=True)
final_ranking.index = final_ranking.index + 1
final_ranking.index.name = 'Rank'

gene_map = {
    '761155': 'rpoB_p.Ser450',
    '2155168': 'katG_p.Ser315', 
    '761110': 'rpoB_p.Asp435',
    '761139': 'rpoB region',
    '4247429': 'embB_p.Met306',
    '4247431': 'embB region',
    '1473246': 'rrs_n.1401',
}
final_ranking['Gene'] = final_ranking['Position'].map(gene_map).fillna('-')
print(final_ranking.to_string())

final_ranking.to_csv('shap_feature_importance.csv')
print("\n✓ Saved to: shap_feature_importance.csv")

print("\n" + "="*60)
print("SHAP ANALYSIS COMPLETE!")
print("="*60)
print("""
Output files:
1. Figure_2Bi_feature_importance.png
2. Figure_2Bii_shap_summary_bar.png
3. Figure_2Biii_shap_beeswarm.png
4. Figure_2Biv_shap_force_plot.png
5. shap_feature_importance.csv
""")