"""
SVM Pipeline for Predicting Rifampicin Resistance in M. tuberculosis
Using the Top 15 LASSO-Selected SNPs

Author: [Your Name]
Based on: Xu et al. BMC Genomic Data (2025) 26:48

Dataset: rifampicin_Top15.csv
Algorithm: Support Vector Machine (SVM)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.svm import SVC
from sklearn.model_selection import (
    train_test_split, 
    cross_val_score, 
    StratifiedKFold,
    LeaveOneOut,
    GridSearchCV
)
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    average_precision_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    precision_recall_curve
)
from sklearn.preprocessing import StandardScaler
import joblib
import warnings
warnings.filterwarnings('ignore')

# Optional: Uncomment if you want SHAP analysis
# import shap

# =============================================================================
# KNOWN TOP 15 SNPs FOR RIFAMPICIN (from the paper Table 1)
# =============================================================================
"""
Based on the paper, the most important SNPs for Rifampicin resistance are:
1. Position 761155 - rpoB_p.Ser450 (most important)
2. Position 2155168 - katG_p.Ser315
3. Position 761110 - rpoB_p.Asp435
4. Position 761139 - rpoB region
5. Position 4247429 - embB_p.Met306
6. Position 1473246 - rrs_n.1401
7. Position 7570 - gyrA region
... and more

These SNPs are located in genes associated with rifampicin resistance,
particularly in the rpoB gene (RNA polymerase beta subunit).
"""

# =============================================================================
# 1. LOAD AND EXPLORE DATA
# =============================================================================

def load_rifampicin_top15(filepath="rifampicin_Top15.csv"):
    """
    Load the rifampicin Top15 dataset.
    
    Expected format:
    - Columns: SNP positions (e.g., '761155', '2155168', etc.) + 'phenotype'
    - Rows: MTB isolates
    - Values: 0 (reference allele) or 1 (variant/mutation)
    - Phenotype: 0 (susceptible) or 1 (resistant)
    """
    df = pd.read_csv(filepath)
    
    print("="*60)
    print("DATASET OVERVIEW: rifampicin_Top15.csv")
    print("="*60)
    print(f"Total samples: {df.shape[0]}")
    print(f"Total features (columns): {df.shape[1]}")
    print(f"\nColumn names:\n{df.columns.tolist()}")
    print(f"\nFirst 5 rows:\n{df.head()}")
    print(f"\nData types:\n{df.dtypes}")
    print(f"\nMissing values:\n{df.isnull().sum().sum()}")
    
    return df

def explore_data(df):
    """
    Detailed exploration of the dataset.
    """
    print("\n" + "="*60)
    print("DATA EXPLORATION")
    print("="*60)
    
    # Identify the phenotype column
    # Common names: 'phenotype', 'Phenotype', 'label', 'resistance', or last column
    phenotype_col = None
    for col in ['phenotype', 'Phenotype', 'label', 'resistance', 'Label']:
        if col in df.columns:
            phenotype_col = col
            break
    
    if phenotype_col is None:
        phenotype_col = df.columns[-1]  # Assume last column is phenotype
        print(f"Assuming '{phenotype_col}' is the phenotype column")
    else:
        print(f"Phenotype column identified: '{phenotype_col}'")
    
    # Class distribution
    print(f"\nClass Distribution:")
    print(df[phenotype_col].value_counts())
    print(f"\nResistance rate: {df[phenotype_col].mean()*100:.2f}%")
    
    # Feature statistics
    feature_cols = [col for col in df.columns if col != phenotype_col]
    print(f"\nNumber of SNP features: {len(feature_cols)}")
    
    # Check if binary (0/1)
    print(f"\nUnique values in features:")
    for col in feature_cols[:5]:  # Show first 5
        print(f"  {col}: {df[col].unique()}")
    
    return phenotype_col, feature_cols

def prepare_data(df, phenotype_col):
    """
    Prepare features (X) and labels (y).
    """
    # Drop the phenotype column and any non-numeric columns (like 'Isolate')
    columns_to_drop = [phenotype_col]
    
    # Check for 'Isolate' column or any other non-numeric columns
    if 'Isolate' in df.columns:
        columns_to_drop.append('Isolate')
        print("Note: Removing 'Isolate' column (sample IDs, not a feature)")
    
    # Also remove any other non-numeric columns
    for col in df.columns:
        if col not in columns_to_drop and df[col].dtype == 'object':
            columns_to_drop.append(col)
            print(f"Note: Removing '{col}' column (non-numeric)")
    
    X = df.drop(columns=columns_to_drop)
    y = df[phenotype_col]
    
    # Convert to numpy arrays
    feature_names = X.columns.tolist()
    X = X.values
    y = y.values
    
    print(f"\nFeatures shape: {X.shape}")
    print(f"Labels shape: {y.shape}")
    print(f"Number of SNP features: {len(feature_names)}")
    print(f"Feature names: {feature_names}")
    
    return X, y, feature_names

# =============================================================================
# 2. SVM MODEL IMPLEMENTATION
# =============================================================================

def train_svm(X_train, y_train, kernel='rbf', C=1.0, gamma='scale'):
    """
    Train Support Vector Machine classifier.
    
    Parameters:
    -----------
    kernel : str
        'rbf' (Radial Basis Function) - Default, good for non-linear data
        'linear' - For linearly separable data
        'poly' - Polynomial kernel
        'sigmoid' - Sigmoid kernel
    
    C : float
        Regularization parameter. Higher C = less regularization (may overfit)
        Lower C = more regularization (may underfit)
    
    gamma : str or float
        Kernel coefficient. 'scale' = 1/(n_features * X.var())
        'auto' = 1/n_features
    """
    # StandardScaler is CRUCIAL for SVM performance
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    
    # Create and train SVM
    svm_model = SVC(
        kernel=kernel,
        C=C,
        gamma=gamma,
        probability=True,  # Required for predict_proba and ROC curves
        class_weight='balanced',  # Handle imbalanced classes
        random_state=42
    )
    
    svm_model.fit(X_train_scaled, y_train)
    
    print(f"\nSVM Model Parameters:")
    print(f"  Kernel: {kernel}")
    print(f"  C: {C}")
    print(f"  Gamma: {gamma}")
    print(f"  Number of support vectors: {svm_model.n_support_}")
    
    return svm_model, scaler

def hyperparameter_tuning(X_train, y_train):
    """
    Optional: Grid search for best hyperparameters.
    """
    print("\n" + "="*60)
    print("HYPERPARAMETER TUNING (Grid Search)")
    print("="*60)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    
    param_grid = {
        'kernel': ['rbf', 'linear'],
        'C': [0.1, 1, 10],
        'gamma': ['scale', 'auto']
    }
    
    svm = SVC(probability=True, class_weight='balanced', random_state=42)
    
    grid_search = GridSearchCV(
        svm, param_grid, cv=5, scoring='f1', n_jobs=-1, verbose=1
    )
    grid_search.fit(X_train_scaled, y_train)
    
    print(f"\nBest parameters: {grid_search.best_params_}")
    print(f"Best F1-score: {grid_search.best_score_:.4f}")
    
    return grid_search.best_params_

# =============================================================================
# 3. MODEL EVALUATION
# =============================================================================

def evaluate_model(model, scaler, X, y, set_name="Test"):
    """
    Comprehensive model evaluation.
    """
    X_scaled = scaler.transform(X)
    
    # Predictions
    y_pred = model.predict(X_scaled)
    y_prob = model.predict_proba(X_scaled)[:, 1]
    
    # Calculate all metrics
    metrics = {
        'Accuracy': accuracy_score(y, y_pred),
        'Precision': precision_score(y, y_pred, zero_division=0),
        'Recall': recall_score(y, y_pred, zero_division=0),
        'F1-Score': f1_score(y, y_pred, zero_division=0),
        'AUROC': roc_auc_score(y, y_prob),
        'AUPR': average_precision_score(y, y_prob)
    }
    
    print(f"\n{'='*50}")
    print(f"{set_name} Set Performance")
    print('='*50)
    for metric, value in metrics.items():
        print(f"{metric:12s}: {value:.4f} ({value*100:.2f}%)")
    
    # Confusion Matrix
    cm = confusion_matrix(y, y_pred)
    tn, fp, fn, tp = cm.ravel()
    print(f"\nConfusion Matrix:")
    print(f"                 Predicted")
    print(f"              Neg    Pos")
    print(f"Actual Neg    {tn:4d}   {fp:4d}")
    print(f"       Pos    {fn:4d}   {tp:4d}")
    
    print(f"\nDetailed Classification Report:")
    print(classification_report(y, y_pred, target_names=['Susceptible', 'Resistant']))
    
    return metrics, y_pred, y_prob

def cross_validation(X, y, n_folds=6):
    """
    Perform stratified k-fold cross-validation (paper uses 6-fold).
    """
    print(f"\n{'='*50}")
    print(f"{n_folds}-Fold Stratified Cross-Validation")
    print('='*50)
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    svm = SVC(
        kernel='rbf', C=1.0, gamma='scale',
        probability=True, class_weight='balanced', random_state=42
    )
    
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
    
    # Multiple scoring metrics
    scoring_metrics = {
        'accuracy': 'accuracy',
        'precision': 'precision',
        'recall': 'recall',
        'f1': 'f1',
        'roc_auc': 'roc_auc'
    }
    
    results = {}
    for name, scorer in scoring_metrics.items():
        scores = cross_val_score(svm, X_scaled, y, cv=skf, scoring=scorer)
        results[name] = scores
        print(f"{name.upper():12s}: {scores.mean():.4f} (+/- {scores.std()*2:.4f})")
    
    return results

def ten_fold_cv(X, y):
    """10-fold cross-validation as mentioned in the paper."""
    return cross_validation(X, y, n_folds=10)

def leave_one_out_cv(X, y, max_samples=500):
    """
    Leave-One-Out Cross-Validation.
    Warning: Very slow for large datasets!
    """
    print(f"\n{'='*50}")
    print("Leave-One-Out Cross-Validation")
    print('='*50)
    
    if len(X) > max_samples:
        print(f"Dataset too large ({len(X)} samples). Using first {max_samples} samples.")
        X = X[:max_samples]
        y = y[:max_samples]
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    svm = SVC(kernel='rbf', C=1.0, gamma='scale', probability=True, 
              class_weight='balanced', random_state=42)
    
    loo = LeaveOneOut()
    scores = cross_val_score(svm, X_scaled, y, cv=loo, scoring='accuracy')
    
    print(f"LOO-CV Accuracy: {scores.mean():.4f}")
    
    return scores.mean()

# =============================================================================
# 4. VISUALIZATION
# =============================================================================

def plot_roc_curve(y_true, y_prob, save_path='svm_rif_roc_curve.png'):
    """Plot ROC curve."""
    fpr, tpr, thresholds = roc_curve(y_true, y_prob)
    auc_score = roc_auc_score(y_true, y_prob)
    
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, color='#2E86AB', lw=2.5, 
             label=f'SVM (AUC = {auc_score:.3f})')
    plt.plot([0, 1], [0, 1], color='gray', lw=1.5, linestyle='--', 
             label='Random Classifier')
    plt.fill_between(fpr, tpr, alpha=0.1, color='#2E86AB')
    
    plt.xlim([-0.02, 1.02])
    plt.ylim([-0.02, 1.02])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title('ROC Curve - SVM for Rifampicin Resistance\n(Top 15 SNPs)', fontsize=14)
    plt.legend(loc='lower right', fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()
    print(f"ROC curve saved to {save_path}")

def plot_precision_recall_curve(y_true, y_prob, save_path='svm_rif_pr_curve.png'):
    """Plot Precision-Recall curve."""
    precision, recall, thresholds = precision_recall_curve(y_true, y_prob)
    aupr = average_precision_score(y_true, y_prob)
    
    plt.figure(figsize=(8, 6))
    plt.plot(recall, precision, color='#28A745', lw=2.5, 
             label=f'SVM (AUPR = {aupr:.3f})')
    plt.fill_between(recall, precision, alpha=0.1, color='#28A745')
    
    plt.xlim([-0.02, 1.02])
    plt.ylim([-0.02, 1.02])
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title('Precision-Recall Curve - SVM for Rifampicin Resistance\n(Top 15 SNPs)', fontsize=14)
    plt.legend(loc='lower left', fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()
    print(f"PR curve saved to {save_path}")

def plot_confusion_matrix(y_true, y_pred, save_path='svm_rif_confusion_matrix.png'):
    """Plot confusion matrix as heatmap."""
    cm = confusion_matrix(y_true, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['Susceptible', 'Resistant'],
                yticklabels=['Susceptible', 'Resistant'],
                annot_kws={'size': 16})
    plt.xlabel('Predicted Label', fontsize=12)
    plt.ylabel('True Label', fontsize=12)
    plt.title('Confusion Matrix - SVM for Rifampicin Resistance\n(Top 15 SNPs)', fontsize=14)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()
    print(f"Confusion matrix saved to {save_path}")

def plot_cv_results(cv_results, save_path='svm_rif_cv_results.png'):
    """Plot cross-validation results."""
    metrics = list(cv_results.keys())
    means = [cv_results[m].mean() for m in metrics]
    stds = [cv_results[m].std() for m in metrics]
    
    plt.figure(figsize=(10, 6))
    bars = plt.bar(metrics, means, yerr=stds, capsize=5, 
                   color=['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#3B1F2B'],
                   edgecolor='black', linewidth=1.2)
    
    # Add value labels on bars
    for bar, mean in zip(bars, means):
        plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                f'{mean:.3f}', ha='center', va='bottom', fontsize=11)
    
    plt.ylim(0, 1.1)
    plt.xlabel('Metric', fontsize=12)
    plt.ylabel('Score', fontsize=12)
    plt.title('6-Fold Cross-Validation Results - SVM for Rifampicin', fontsize=14)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.show()
    print(f"CV results saved to {save_path}")

# =============================================================================
# 5. SAVE/LOAD MODEL
# =============================================================================

def save_model(model, scaler, filepath='rifampicin_SVM_Top15.sav'):
    """Save the trained model and scaler."""
    model_data = {
        'model': model,
        'scaler': scaler,
        'model_type': 'SVM',
        'drug': 'rifampicin',
        'features': 'Top15'
    }
    joblib.dump(model_data, filepath)
    print(f"\nModel saved to: {filepath}")

def load_saved_model(filepath='rifampicin_SVM_Top15.sav'):
    """Load a previously saved model."""
    model_data = joblib.load(filepath)
    print(f"Model loaded from: {filepath}")
    return model_data['model'], model_data['scaler']

# =============================================================================
# 6. PREDICT NEW SAMPLES
# =============================================================================

def predict_new_samples(model, scaler, X_new, feature_names=None):
    """
    Predict resistance for new MTB isolates.
    """
    X_new_scaled = scaler.transform(X_new)
    
    predictions = model.predict(X_new_scaled)
    probabilities = model.predict_proba(X_new_scaled)[:, 1]
    
    results = pd.DataFrame({
        'Prediction': ['Resistant' if p == 1 else 'Susceptible' for p in predictions],
        'Probability_Resistant': probabilities
    })
    
    return results

# =============================================================================
# 7. MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function to run the complete SVM pipeline for Rifampicin.
    """
    print("\n" + "="*70)
    print(" SVM PIPELINE FOR RIFAMPICIN RESISTANCE PREDICTION ")
    print(" Using Top 15 LASSO-Selected SNPs ")
    print("="*70)
    
    # =========================================================================
    # STEP 1: Load Data
    # =========================================================================
    print("\n>>> STEP 1: Loading Data")
    
    # UPDATE THIS PATH to your actual file location
    DATA_PATH = "Data/rifampicin_Top15.csv"
    
    try:
        df = load_rifampicin_top15(DATA_PATH)
    except FileNotFoundError:
        print(f"\n⚠️  File '{DATA_PATH}' not found!")
        print("Please download from: https://github.com/microbial123/MTB-AMR/tree/main/Data")
        print("\nCreating DEMO data for testing the pipeline...")
        
        # Create demo data matching expected structure
        np.random.seed(42)
        n_samples = 500
        
        # Simulate Top 15 SNP positions (from paper)
        snp_positions = ['761155', '2155168', '761110', '761139', '761109',
                        '4247429', '1634609', '761140', '3847087', '760314',
                        '7570', '7582', '7585', '1673432', '4247431']
        
        # Generate binary SNP data
        demo_data = {pos: np.random.randint(0, 2, n_samples) for pos in snp_positions}
        demo_data['phenotype'] = np.random.randint(0, 2, n_samples)
        
        df = pd.DataFrame(demo_data)
        print(f"Demo dataset created: {df.shape}")
    
    # =========================================================================
    # STEP 2: Explore and Prepare Data
    # =========================================================================
    print("\n>>> STEP 2: Exploring Data")
    phenotype_col, feature_cols = explore_data(df)
    
    print("\n>>> STEP 3: Preparing Features and Labels")
    X, y, feature_names = prepare_data(df, phenotype_col)
    
    # =========================================================================
    # STEP 4: Split Data (90% train, 10% test - as per paper)
    # =========================================================================
    print("\n>>> STEP 4: Splitting Data (90% Train / 10% Test)")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.10, random_state=42, stratify=y
    )
    print(f"Training samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    
    # =========================================================================
    # STEP 5: Train SVM Model
    # =========================================================================
    print("\n>>> STEP 5: Training SVM Model")
    svm_model, scaler = train_svm(X_train, y_train, kernel='rbf', C=1.0, gamma='scale')
    
    # Optional: Hyperparameter tuning (uncomment to run)
    # best_params = hyperparameter_tuning(X_train, y_train)
    
    # =========================================================================
    # STEP 6: Evaluate Model
    # =========================================================================
    print("\n>>> STEP 6: Evaluating Model")
    
    # Training set performance
    train_metrics, _, _ = evaluate_model(svm_model, scaler, X_train, y_train, "Training")
    
    # Test set performance
    test_metrics, y_pred, y_prob = evaluate_model(svm_model, scaler, X_test, y_test, "Test")
    
    # =========================================================================
    # STEP 7: Cross-Validation
    # =========================================================================
    print("\n>>> STEP 7: Cross-Validation")
    
    # 6-fold CV (as per paper)
    cv_results_6fold = cross_validation(X, y, n_folds=6)
    
    # 10-fold CV
    cv_results_10fold = cross_validation(X, y, n_folds=10)
    
    # LOO-CV (optional - slow)
    # loo_accuracy = leave_one_out_cv(X, y)
    
    # =========================================================================
    # STEP 8: Generate Visualizations
    # =========================================================================
    print("\n>>> STEP 8: Generating Visualizations")
    
    plot_roc_curve(y_test, y_prob)
    plot_precision_recall_curve(y_test, y_prob)
    plot_confusion_matrix(y_test, y_pred)
    plot_cv_results(cv_results_6fold)
    
    # =========================================================================
    # STEP 9: Save Model
    # =========================================================================
    print("\n>>> STEP 9: Saving Model")
    save_model(svm_model, scaler, 'rifampicin_SVM_Top15.sav')
    
    # =========================================================================
    # STEP 10: Summary Results
    # =========================================================================
    print("\n" + "="*70)
    print(" FINAL SUMMARY: SVM Performance for Rifampicin Resistance ")
    print("="*70)
    
    summary_df = pd.DataFrame({
        'Metric': list(test_metrics.keys()),
        'Training Set': [train_metrics[k] for k in test_metrics.keys()],
        'Test Set': list(test_metrics.values()),
        '6-Fold CV Mean': [cv_results_6fold.get(k.lower().replace('-', '_').replace('score', ''), 
                          cv_results_6fold.get(k.lower().replace('-score', ''), np.nan)).mean() 
                         if k.lower().replace('-', '_').replace('score', '') in cv_results_6fold 
                         or k.lower().replace('-score', '') in cv_results_6fold else np.nan 
                         for k in test_metrics.keys()]
    })
    
    print("\n" + summary_df.to_string(index=False))
    
    # Save summary to CSV
    summary_df.to_csv('svm_rifampicin_results_summary.csv', index=False)
    print("\n✓ Results saved to 'svm_rifampicin_results_summary.csv'")
    
    # Compare with paper's reported SVM accuracy (97.07%)
    print("\n" + "-"*50)
    print("COMPARISON WITH PAPER (Xu et al. 2025)")
    print("-"*50)
    print(f"Paper reported SVM accuracy: 97.07%")
    print(f"Your SVM test accuracy:      {test_metrics['Accuracy']*100:.2f}%")
    
    return svm_model, scaler, test_metrics, cv_results_6fold

# =============================================================================
# RUN THE PIPELINE
# =============================================================================

if __name__ == "__main__":
    model, scaler, metrics, cv_results = main()